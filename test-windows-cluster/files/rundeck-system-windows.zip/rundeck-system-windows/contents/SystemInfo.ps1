#Requires -Version 4

<#
.NOTES
    Created on:             06/03/2016
    Created by:             Luisao
    Filename:               SystemInfo.ps1
.DESCRIPTION
      
.EXAMPLE
    PS> .\SystemInfo.ps1

#>
[CmdletBinding(SupportsShouldProcess)]
param (
    
)
begin {
    function Convert-Resource($file, $outputFile) {
	
		$serverUUID=$file.system.rundeck.serverUUID
		$timestampEpoch=$file.system.timestamp.epoch
		$datetime=$file.system.timestamp.datetime
		$node=$file.system.rundeck.node
		$rundeckVersion=$file.system.rundeck.version
		$executionsModeActive=$file.system.executions.active
		$executionsMode=$file.system.executions.executionMode
		$cpuLoadaverage=$file.system.stats.cpu.loadAverage.'#text'
		$cpuLoadaverageUnit=$file.system.stats.cpu.loadAverage.unit
		$cpuCores=$file.system.stats.cpu.processors
		$memMax=$file.system.stats.memory.max
		$memFree=$file.system.stats.memory.free
		$memTotal=$file.system.stats.memory.total
		$schedulerRunning=$file.system.stats.scheduler.running
		$schedulerThreadpoolSize=$file.system.stats.scheduler.threadPoolSize
		
        Write-Verbose "Generating resoruce output file"
		
		"<project>" | Out-File $outputFile 
		"	<node name='$serverUUID' tags='cluster'>" | Out-File $outputFile -Append
		"	      <attribute name='timestamp-epoch' value='$timestampEpoch'/>" | Out-File $outputFile -Append
		"	      <attribute name='timestamp-datetime' value='$datetime'/>" | Out-File $outputFile -Append
		"	      <attribute name='rundeck-node' value='$node'/>" | Out-File $outputFile -Append
		"	      <attribute name='rundeck-version' value='$rundeckVersion'/>" | Out-File $outputFile -Append
		"	      <attribute name='rundeck-serveruuid' value='$serverUUID'/>" | Out-File $outputFile -Append
		"	      <attribute name='executions-mode-active' value='$executionsModeActive'/>" | Out-File $outputFile -Append
		"	      <attribute name='executions-mode' value='$executionsMode'/>" | Out-File $outputFile -Append
		"	      <attribute name='cpu-loadaverage' value='$cpuLoadaverage'/>" | Out-File $outputFile -Append
		"	      <attribute name='cpu-loadaverage-unit' value='$cpuLoadaverageUnit'/>" | Out-File $outputFile -Append
		"	      <attribute name='cpu-cores' value='$cpuCores'/>" | Out-File $outputFile -Append
		"	      <attribute name='mem-max' value='$memMax'/>" | Out-File $outputFile -Append
		"	      <attribute name='mem-free' value='$memFree'/>" | Out-File $outputFile -Append
		"	      <attribute name='mem-total' value='$memTotal'/>" | Out-File $outputFile -Append
		"	      <attribute name='scheduler-running' value='$schedulerRunning'/>" | Out-File $outputFile -Append
		"	      <attribute name='scheduler-threadpool-size' value='$schedulerThreadpoolSize'/>" | Out-File $outputFile -Append
		"    </node>" | Out-File $outputFile -Append
		"</project>" | Out-File $outputFile -Append

    }
}

process {
    $ecode=0
    try {
        if($Env:RD_JOB_LOGLEVEL -ieq "DEBUG"){
            $VerbosePreference="Continue"
            $DebugPreference="Continue"
        }
					
		$token =$env:RD_CONFIG_APIKEY
		$url = $env:RD_CONFIG_URL
		$outputFile = $env:RD_CONFIG_FILE
		$outputFormat = $env:RD_CONFIG_FORMAT
		
		#local variables
		$responseType="application/xml"
		$temporalFile="c:\Windows\temp\$(Get-Random)systeminfo.xml"

		Write-Verbose "Call API"
		Write-Verbose "Output format $outputFormat"
		
		#calling the API and writing the repostonse to a XML file
		$response = Invoke-WebRequest "$url/api/16/system/info" -outfile $temporalFile -Header @{"X-Rundeck-Auth-Token" = $token; "Accept" =$responseType} -ContentType $responseType -Method GET -UseBasicParsing

		#parse the xml file to an object
		[xml]$file = get-content $temporalFile


		Write-Verbose $file.system.rundeck.version
		Write-Verbose $file.system.rundeck.node
		Write-Verbose $file.system.rundeck.serverUUID
		Write-Verbose $file.system.timestamp.datetime
		Write-Verbose $file.system.timestamp.epoch
		Write-Verbose $file.system.timestamp.unit
		Write-Verbose $file.system.stats.cpu.loadAverage.'#text'

		if( $outputFormat -eq "resourcexml"){
			$ecode=Convert-Resource  $file $outputFile
		}
		
		if( $outputFormat -eq "xml"){
			Write-Verbose "Generate XML file"
			
			copy $temporalFile $outputFile
		}
		
		
		
		Write-Verbose "Remove temporary file"
		del $temporalFile
		
		Write-Verbose "Print file"
		
		Get-Content	$outputFile

        
    } catch {
        Write-Error "Error: $($_.Exception.Message) - Line Number: $($_.InvocationInfo.ScriptLineNumber)"
        exit -4441
    }
	
	Write-Verbose "exit code: $ecode"
    exit $ecode
}
