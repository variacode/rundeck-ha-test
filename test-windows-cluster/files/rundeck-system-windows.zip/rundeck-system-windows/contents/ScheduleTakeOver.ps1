#Requires -Version 4

<#
.NOTES
    Created on:             06/16/2016
    Created by:             Luisao
    Filename:               ScheduleTakeOver.ps1
.DESCRIPTION
      
.EXAMPLE
    PS> .\ScheduleTakeOver.ps1

#>
[CmdletBinding(SupportsShouldProcess)]
param (
    
)
begin {
	function List-Projects($url,$token) {
		#local variables
		$responseType="application/json"
		$temporalFile="c:\Windows\temp\$(Get-Random)projectlist.json"
		
		#calling the API and writing the repostonse to a XML file
		$response = Invoke-WebRequest "$url/api/16/projects" -Header @{"X-Rundeck-Auth-Token" = $token; "Accept" =$responseType} -ContentType $responseType -Method GET -UseBasicParsing
				
		$myCustomObject = $response | ConvertFrom-Json
		
		return $myCustomObject 
	}
	
	
	function Check-Threshold($timestamp_threshold,$timestamp) {
	
		if ($timestamp_threshold  -ne $null -and $timestamp  -ne $null){
		
			
			$unixEpochStart = new-object DateTime 1970,1,1,0,0,0,([DateTimeKind]::Utc)
			$currenttime =  [int]([DateTime]::UtcNow - $unixEpochStart).TotalSeconds
			
			
			$timestamp=$timestamp/1000
			
			$elapsed= $currenttime - $timestamp
			
			Write-Verbose "Currenttime: $currenttime"
			Write-Verbose "Node-timestamp: $timestamp"
			Write-Verbose "Elapsed: $elapsed"
			
			
			if ( $elapsed -lt $timestamp_threshold ){
				Write-Host "[info]: Skipping takeover: Threshold not exceeded. $elapsed secs elapsed between current time and timestamp."				
				return $false
			}else{
				Write-Host "[warn]: Threshold exceeded by $elapsed seconds. Can take over schedules"
				return $true
			}
			
			
			  
			
		}
	

	}
	
	function Process-Project($url,$token,$project,$uuid) {
		#local variables
		$responseType="application/xml"			
		
		if($uuid -eq "all"){
			$body = "<takeoverSchedule><server all='true'/><project name='$project'/></takeoverSchedule>"
		}else{
			$body = "<takeoverSchedule><server uuid='$uuid'/><project name='$project'/></takeoverSchedule>"
		}
		
		$temporalFile="c:\Windows\temp\$(Get-Random)takeover_$project.xml"

		
		#calling the API and writing the repostonse to a XML file
		$response = Invoke-WebRequest "$url/api/14/scheduler/takeover" -Header @{"X-Rundeck-Auth-Token"=$token; "Accept"=$responseType} -ContentType $responseType  -outfile $temporalFile -Body $body -Method PUT -UseBasicParsing
				
		#parse the xml file to an object
		[xml]$file = get-content $temporalFile
		
		$total = $file.takeoverSchedule.jobs.total
		$successful = $file.takeoverSchedule.jobs.successful.count
		$failed = $file.takeoverSchedule.jobs.failed.count
		
		Write-Host "[info]: Generating summary..." 
		
		Write-Host ("[info]: Jobs total: " + $total)
		
		if($successful -gt 0 ){
			Write-Host ("[info]: successfully took over $successful jobs" )
			
			foreach ($job in $file.takeoverSchedule.jobs.successful.job)
			{				
				
				Write-Host ("[info]: Job: " + $job.id)
				
			}
		}
		
		if($failed -gt 0 ){
			Write-Host ("[info]: failed to take over $failed jobs" )
			Write-Host ("[info]: Not all jobs taken over: $failed out of $total. jobs: " )
			
			foreach ($job in $file.takeoverSchedule.jobs.failed.job)
			{				
				
				Write-Host ("[info]: Job Failed: " + $job.id)
				
			}			
			
		}
		
		del $temporalFile
		
		
	}
}

process {
    $ecode=0
    try {
        if($Env:RD_JOB_LOGLEVEL -ieq "DEBUG"){
            $VerbosePreference="Continue"
            $DebugPreference="Continue"
        }
		
		
		#get parameters
					
		$token =$env:RD_CONFIG_APIKEY
		$url = $env:RD_CONFIG_URL
		$uuid = $env:RD_CONFIG_UUID
		$project = $env:RD_CONFIG_PROJECT
		$exclude_project = $env:RD_CONFIG_EXCLUDE_PROJECT
		$timestamp_threshold = $env:RD_CONFIG_TIMESTAMP_THRESHOLD
		$timestamp = $env:RD_CONFIG_TIMESTAMP
		
		#print parameters verbose mode
		Write-Verbose "url: $url"
		Write-Verbose "uuid: $uuid"
		Write-Verbose "project: $project"
		Write-Verbose "exclude_project: $exclude_project"
		Write-Verbose "timestamp_threshold: $timestamp_threshold"
		Write-Verbose "Node Timestamp: $timestamp"
		
		Write-Host  "[info]: Looking up all projects ..." -ForegroundColor Green 
		
		#get List Project
		$listProjects =  List-Projects  $url $token
		
		
		#get total projects and detail
		$countProjects = $listProjects.length
		
		$listProjectsName =""		
		
		foreach($obj in $listProjects)
		{			
			$listProjectsName = $listProjectsName + $obj.name + " "
		}
		
				
		Write-Host  "[info]: Processing $countProjects projects: $listProjectsName" -ForegroundColor Green 
		
		#iterate Projects
		foreach($obj in $listProjects)
		{	
			
			if($exclude_project -eq  $obj.name) {
				#Skipping excluded project
				Write-Host ("[info]: Skipping excluded project: " + $obj.name)
			}else{
			
				#Sprocess projects
				Write-Host ("[info]: Project: " + $obj.name)
				
				#Check if the threshold is xceded
				$exceded = Check-Threshold $timestamp_threshold $timestamp
				
				if($exceded -eq $true){
					#take over a project
					Process-Project $url $token $obj.name $uuid
				}				
				
			}	
			
		}
		

        
    } catch {
        Write-Error "Error: $($_.Exception.Message) - Line Number: $($_.InvocationInfo.ScriptLineNumber)"
        exit -4441
    }
	
	Write-Verbose "exit code: $ecode"
    exit $ecode
}
